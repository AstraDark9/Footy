// ============================================================================
// UTILS.js — vector math and small generic helpers
// ============================================================================

const Vec = {
  add: (a, b) => ({ x: a.x + b.x, y: a.y + b.y }),
  sub: (a, b) => ({ x: a.x - b.x, y: a.y - b.y }),
  scale: (a, s) => ({ x: a.x * s, y: a.y * s }),
  len: (a) => Math.hypot(a.x, a.y),
  dist: (a, b) => Math.hypot(a.x - b.x, a.y - b.y),
  norm: (a) => {
    const l = Math.hypot(a.x, a.y);
    return l < 1e-6 ? { x: 0, y: 0 } : { x: a.x / l, y: a.y / l };
  },
  dot: (a, b) => a.x * b.x + a.y * b.y,
  angle: (a) => Math.atan2(a.y, a.x),
  fromAngle: (ang, mag = 1) => ({ x: Math.cos(ang) * mag, y: Math.sin(ang) * mag }),
  lerp: (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }),
  clone: (a) => ({ x: a.x, y: a.y }),
};

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function lerp(a, b, t) { return a + (b - a) * t; }
function randRange(min, max) { return min + Math.random() * (max - min); }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

// shortest signed angle difference b-a, wrapped to [-PI, PI]
function angleDiff(a, b) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return d;
}

function moveAngleTowards(current, target, maxDelta) {
  const d = angleDiff(current, target);
  if (Math.abs(d) <= maxDelta) return target;
  return current + Math.sign(d) * maxDelta;
}
