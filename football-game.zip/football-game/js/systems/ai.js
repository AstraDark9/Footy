// ============================================================================
// ai.js — outfield player AI. Each team gets a small "brain" that assigns
// roles (chase / mark / support / return) per tick so we never get the
// classic "everyone chases the ball" arcade-AI problem, then each player
// steers toward its assigned target using the same steerTo() the human
// player uses.
// ============================================================================

class TeamAI {
  constructor(team, match) {
    this.team = team;
    this.match = match;
  }

  // Called once per frame for this whole team (excluding the human-controlled
  // player and the goalkeeper, which is handled by GoalkeeperAI).
  update(dt) {
    const team = this.team;
    const ball = this.match.ball;
    const opponent = this.match.otherTeam(team);
    const weHaveBall = ball.owner && ball.owner.team === team;
    const theyHaveBall = ball.owner && ball.owner.team === opponent;
    const ballNormX = clamp(ball.pos.x / CONFIG.PITCH.WIDTH, 0, 1);

    const controllable = team.outfield().filter(p => !p.isUserControlled);

    // --- decide who presses the ball (limited count, closest players only) ---
    const byDist = controllable
      .map(p => ({ p, d: Vec.dist(p.pos, ball.pos) }))
      .sort((a, b) => a.d - b.d);

    const chaseRange = weHaveBall ? 0 : 26; // don't send half the team box-to-box chasing a loose ball far away
    const chasers = [];
    for (const { p, d } of byDist) {
      if (chasers.length >= CONFIG.AI.CHASERS_MAX) break;
      if (d <= chaseRange || (!ball.owner && d < 40)) chasers.push(p);
    }
    const chaserIds = new Set(chasers.map(p => p.id));

    // --- assign markers when the opponent has the ball ---
    let markers = new Map();
    if (theyHaveBall) {
      const opponents = opponent.outfield()
        .filter(op => op !== ball.owner)
        .sort((a, b) => Vec.dist(a.pos, team.goalCenter()) - Vec.dist(b.pos, team.goalCenter()));
      const defenders = controllable
        .filter(p => !chaserIds.has(p.id))
        .sort((a, b) => this.role(a).defend - this.role(b).defend).reverse();

      let oi = 0;
      for (const d of defenders) {
        if (oi >= opponents.length) break;
        const opp = opponents[oi];
        if (Vec.dist(d.formationSlotWorld || d.pos, opp.pos) < CONFIG.AI.MARK_RADIUS) {
          markers.set(d.id, opp);
          oi++;
        }
      }
    }

    for (const p of controllable) {
      p.formationSlotWorld = team.slotWorldPos(p, ballNormX);

      if (chaserIds.has(p.id)) {
        p.aiState = "CHASE";
        this.doChase(p, ball, dt);
        continue;
      }

      if (markers.has(p.id)) {
        p.aiState = "MARK";
        this.doMark(p, markers.get(p.id), dt);
        continue;
      }

      p.aiState = weHaveBall ? "SUPPORT" : "RETURN";
      this.doPositional(p, weHaveBall, ball, dt);
    }
  }

  role(p) { return CONFIG.POSITION_ROLE[p.position] || { defend: 0.5, attack: 0.5, holdLine: 0.5 }; }

  doChase(p, ball, dt) {
    // intercept the ball's near-future position rather than chasing its current spot
    const leadTime = clamp(Vec.dist(p.pos, ball.pos) / Math.max(3, p.maxSpeed(true)), 0, 0.5);
    const predicted = Vec.add(ball.pos, Vec.scale(ball.vel, leadTime));
    p.steerTo(predicted, true, dt);

    if (Actions.canAttemptTackle(p, ball) && p.canTackle()) {
      if (Math.random() < 0.06) Actions.startTackle(p);
    }
  }

  doMark(p, opponent, dt) {
    // stand goal-side, slightly between the opponent and our goal, a step off them
    const goal = p.team.goalCenter();
    const toGoal = Vec.norm(Vec.sub(goal, opponent.pos));
    const markPoint = Vec.add(opponent.pos, Vec.scale(toGoal, 1.6));
    p.steerTo(markPoint, Vec.dist(p.pos, markPoint) > 4, dt);
  }

  doPositional(p, weHaveBall, ball, dt) {
    let target = p.formationSlotWorld;

    if (weHaveBall) {
      const role = this.role(p);
      // attacking players push forward off the ball to offer support/width
      const forwardBias = (p.team.attackDir) * role.attack * 6;
      const spread = Math.sin((p.id * 13) % 7) * 3; // deterministic-ish variety, avoids everyone stacking
      target = { x: target.x + forwardBias, y: clamp(target.y + spread, 2, CONFIG.PITCH.HEIGHT - 2) };

      // if the ball carrier is a teammate nearby, offer a passing lane by
      // drifting away from other supporting teammates
      target = this.avoidTeammateStacking(p, target);
    }

    const dist = Vec.dist(p.pos, target);
    p.steerTo(target, dist > 10, dt);
  }

  avoidTeammateStacking(p, target) {
    const nearby = p.team.outfield().filter(o => o !== p && Vec.dist(o.pos, target) < 6);
    if (nearby.length === 0) return target;
    let push = { x: 0, y: 0 };
    for (const o of nearby) {
      const away = Vec.sub(target, o.pos);
      const d = Math.max(0.5, Vec.len(away));
      push = Vec.add(push, Vec.scale(Vec.norm(away), (6 - d)));
    }
    return Vec.add(target, Vec.scale(push, 0.4));
  }
}
