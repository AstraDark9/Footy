// ============================================================================
// goalkeeper.js — dedicated GK AI: hold the line, track the ball laterally,
// come off the line to close down through balls, attempt saves, collect
// or punch clear, and restart play with a throw/kick when holding the ball.
// ============================================================================

class GoalkeeperAI {
  constructor(team, match) {
    this.team = team;
    this.match = match;
    this.gk = team.goalkeeper();
    this.holdTimer = 0; // counts up while GK is holding the ball before restart
  }

  update(dt) {
    const gk = this.gk;
    if (gk.isUserControlled) return; // human is playing as the keeper
    const ball = this.match.ball;
    const goal = this.team.goalCenter();
    const dir = this.team.attackDir; // 1 => our goal at x=0, defending toward +x is "out"
    const goalLineX = goal.x;
    const boxDepth = CONFIG.PITCH.PENALTY_BOX_DEPTH;
    const boxHalfWidth = CONFIG.PITCH.PENALTY_BOX_WIDTH / 2;

    if (ball.owner === gk) {
      this.holdTimer += dt;
      this.doRestart(dt);
      return;
    }
    this.holdTimer = 0;

    const ballInBox = Math.abs(ball.pos.y - goal.y) < boxHalfWidth &&
      (dir === 1 ? ball.pos.x < boxDepth : ball.pos.x > CONFIG.PITCH.WIDTH - boxDepth);

    const ballDist = Vec.dist(gk.pos, ball.pos);
    const dangerousShot = ball.owner && ball.owner.team !== this.team &&
      ((dir === 1 && ball.vel.x < -6) || (dir === -1 && ball.vel.x > 6)) &&
      Math.abs(ball.pos.x - goalLineX) < 22;

    let target;
    if (dangerousShot) {
      // shot-stopping: move to intercept the ball's flight path toward goal
      target = this.predictInterceptOnGoalLine(ball, goal, dir);
      gk.aiState = "GK_SAVE";
    } else if (ballInBox && !ball.owner) {
      // loose ball in the box: come and claim it
      target = ball.pos;
      gk.aiState = "GK_CLAIM";
    } else if (ball.owner && ball.owner.team !== this.team && ballDist < 10 && ballInBox) {
      target = this.narrowAngle(ball.pos, goal, dir);
      gk.aiState = "GK_NARROW";
    } else {
      // hold near goal, shadow the ball laterally
      const maxAdvance = 9; // how far off the line the keeper will venture
      const advance = clamp((this.match.ballThirdBias(this.team) ) * maxAdvance, 0, maxAdvance);
      const x = goalLineX + dir * advance;
      const y = clamp(ball.pos.y, goal.y - boxHalfWidth * 0.8, goal.y + boxHalfWidth * 0.8);
      target = { x, y };
      gk.aiState = "GK_HOLD";
    }

    const sprint = gk.aiState === "GK_SAVE" || gk.aiState === "GK_CLAIM";
    gk.steerTo(target, sprint, dt);

    // attempt to collect the ball if close and it's not a hot shot in the
    // instant it arrives (that's handled by Match's collision/save resolution)
  }

  predictInterceptOnGoalLine(ball, goal, dir) {
    // find time for ball to reach goal-line x, then aim for that y (clamped
    // to inside the goal mouth so the GK doesn't run wildly off unnecessarily)
    const speedX = ball.vel.x || 0.001;
    const t = clamp((goal.x - ball.pos.x) / speedX, 0, 1.2);
    const predictedY = ball.pos.y + ball.vel.y * t;
    const halfGoal = CONFIG.PITCH.GOAL_WIDTH / 2 + 1.2;
    const y = clamp(predictedY, goal.y - halfGoal, goal.y + halfGoal);
    // move partway out from the line toward the ball to cut the angle
    const outX = goal.x + dir * clamp(Vec.dist(ball.pos, goal) * 0.15, 0.5, 3.5);
    return { x: outX, y };
  }

  narrowAngle(ballPos, goal, dir) {
    const toBall = Vec.sub(ballPos, goal);
    const d = Vec.len(toBall);
    const advance = clamp(d * 0.35, 1, 6);
    return Vec.add(goal, Vec.scale(Vec.norm(toBall), advance));
  }

  doRestart(dt) {
    const gk = this.gk;
    // after a short hold, distribute to an open teammate or clear it long
    if (this.holdTimer < 0.6) {
      gk.vel = { x: 0, y: 0 };
      return;
    }
    const teammates = this.team.outfield();
    let best = null, bestScore = -Infinity;
    for (const t of teammates) {
      const openness = this.match.spaceAroundPoint(t.pos, t.team);
      const advance = this.team.attackDir === 1 ? t.pos.x : (CONFIG.PITCH.WIDTH - t.pos.x);
      const dist = Vec.dist(gk.pos, t.pos);
      if (dist > 40 || dist < 4) continue;
      const score = openness * 1.5 + advance * 0.05 - dist * 0.02;
      if (score > bestScore) { bestScore = score; best = t; }
    }
    if (!best) best = teammates[Math.floor(teammates.length / 2)];
    const dir = Vec.norm(Vec.sub(best.pos, gk.pos));
    Actions.pass(this.match.ball, gk, dir, 0.85, best);
  }
}
