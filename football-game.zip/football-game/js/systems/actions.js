// ============================================================================
// actions.js — the actual mechanics behind passing, shooting and tackling.
// Pure functions operating on Player/Ball/Team so both the human input
// layer and the AI layer call the exact same code paths (fairness + reuse).
// ============================================================================

const Actions = {
  /**
   * @param passer Player currently holding the ball
   * @param dir {x,y} normalized intended direction
   * @param power 0..1 charge level
   * @param targetTeammate optional Player being targeted (used for accuracy assist + AI)
   */
  pass(ball, passer, dir, power, targetTeammate = null) {
    const skill = passer.attr("passing") / 99;
    const dist = targetTeammate ? Vec.dist(passer.pos, targetTeammate.pos) : 15;

    // accuracy: better passers deviate less; long passes deviate more
    const rangePenalty = clamp(dist / 45, 0, 1) * 0.5;
    const spread = lerp(CONFIG.PASS.INACCURACY_BASE, CONFIG.PASS.INACCURACY_MIN, skill) * (1 + rangePenalty);
    const errorAngle = randRange(-spread, spread);
    const finalDir = Vec.fromAngle(Vec.angle(dir) + errorAngle);

    const speed = clamp(
      lerp(CONFIG.PASS.MIN_SPEED, CONFIG.PASS.BASE_SPEED, power) * (0.85 + skill * 0.3),
      CONFIG.PASS.MIN_SPEED, CONFIG.PASS.BASE_SPEED * 1.15
    );

    const isLong = dist > CONFIG.PASS.LOFT_THRESHOLD_DIST;
    const vz = isLong ? clamp(dist * 0.09, 2, 7) : 0;

    ball.kick(Vec.scale(finalDir, speed), vz, passer);
    return { speed, spread };
  },

  shoot(ball, shooter, dir, chargeFrac, targetPoint) {
    const skill = shooter.attr("shooting") / 99;
    const spread = lerp(CONFIG.SHOT.INACCURACY_BASE, CONFIG.SHOT.INACCURACY_MIN, skill);
    const errorAngle = randRange(-spread, spread);
    const finalDir = Vec.fromAngle(Vec.angle(dir) + errorAngle);

    const speed = clamp(
      lerp(CONFIG.SHOT.MIN_SPEED, CONFIG.SHOT.BASE_SPEED, chargeFrac) * (0.85 + skill * 0.35),
      CONFIG.SHOT.MIN_SPEED, CONFIG.SHOT.BASE_SPEED * 1.2
    );

    // low-power / close-range shots stay low; high power adds some loft
    const loft = CONFIG.SHOT.LOFT_BASE * chargeFrac * (1 - skill * 0.4);
    const vz = clamp(speed * loft, 0, 9);

    ball.kick(Vec.scale(finalDir, speed), vz, shooter);
    return { speed, spread };
  },

  /**
   * Attempt a tackle. Returns true if it starts a tackle attempt (resolution
   * happens a few frames later in Match's update, once contact is confirmed).
   */
  canAttemptTackle(tackler, ball) {
    if (!tackler.canTackle()) return false;
    if (ball.owner === tackler) return false;
    const dist = Vec.dist(tackler.pos, ball.pos);
    return dist <= CONFIG.TACKLE.RANGE + tackler.radius();
  },

  startTackle(tackler) {
    tackler.tackle = { active: true, timer: 0, phase: "windup" };
    tackler.tackleCooldown = CONFIG.TACKLE.COOLDOWN;
  },

  /**
   * Resolve a tackle attempt against the current ball holder (or loose ball).
   * Success depends on distance, facing/direction, relative attributes and a
   * timing window (must connect during the "active" phase).
   */
  resolveTackle(tackler, ball) {
    const dist = Vec.dist(tackler.pos, ball.pos);
    if (dist > CONFIG.TACKLE.RANGE + tackler.radius() + 0.4) {
      return { success: false, reason: "out_of_range" };
    }

    const toBall = Vec.norm(Vec.sub(ball.pos, tackler.pos));
    const facing = Vec.fromAngle(tackler.facing);
    const facingAlignment = clamp(Vec.dot(toBall, facing), -1, 1); // 1 = facing the ball dead-on

    if (facingAlignment < 0.15) {
      return { success: false, reason: "bad_angle" };
    }

    const carrier = ball.owner;
    let successChance = CONFIG.TACKLE.BASE_SUCCESS;
    successChance += (tackler.attr("tackling") - 50) / 160;
    successChance += (facingAlignment - 0.6) * 0.35;

    if (carrier) {
      successChance -= (carrier.attr("dribbling") - 50) / 200;
      successChance -= (carrier.attr("strength") - tackler.attr("strength")) / 260;
      // sliding in from directly behind a moving carrier is riskier (foul-prone) -> lower success
      const carrierMoveDir = Vec.len(carrier.vel) > 0.3 ? Vec.norm(carrier.vel) : facing;
      const fromBehind = Vec.dot(carrierMoveDir, toBall) > 0.5;
      if (fromBehind) successChance -= 0.12;
    }

    successChance = clamp(successChance, 0.08, 0.92);
    const success = Math.random() < successChance;

    if (success) {
      // knock the ball loose in the tackler's facing direction with some randomness
      const knockDir = Vec.norm(Vec.add(facing, Vec.fromAngle(randRange(-0.4, 0.4))));
      ball.kick(Vec.scale(knockDir, randRange(3, 6)), 0, tackler);
      if (carrier) carrier.stun(0.35);
    } else if (carrier) {
      // failed tackle: small chance of a foul-ish stumble for the tackler
      tackler.stun(0.25);
    }

    return { success, carrier };
  },
};
