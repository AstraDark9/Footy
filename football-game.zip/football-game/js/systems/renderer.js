// ============================================================================
// renderer.js — all canvas drawing. Keeps game logic files free of any
// rendering code.
// ============================================================================

class Renderer {
  constructor(canvas, camera) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.camera = camera;
  }

  clear() {
    const ctx = this.ctx;
    ctx.fillStyle = "#0b3d1a";
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  }

  drawPitch() {
    const ctx = this.ctx;
    const cam = this.camera;
    const P = CONFIG.PITCH;

    // mown-stripe effect
    const stripeCount = 12;
    for (let i = 0; i < stripeCount; i++) {
      const x0 = (P.WIDTH / stripeCount) * i;
      const x1 = (P.WIDTH / stripeCount) * (i + 1);
      ctx.fillStyle = i % 2 === 0 ? "#0e4620" : "#0b3d1a";
      this.polygon([
        { x: x0, y: 0 }, { x: x1, y: 0 }, { x: x1, y: P.HEIGHT }, { x: x0, y: P.HEIGHT },
      ]);
    }

    ctx.strokeStyle = "rgba(255,255,255,0.85)";
    ctx.lineWidth = Math.max(1, cam.worldScaleToScreen(0.12));

    // outer boundary
    this.strokeRect(0, 0, P.WIDTH, P.HEIGHT);
    // halfway line
    this.strokeLine({ x: P.WIDTH / 2, y: 0 }, { x: P.WIDTH / 2, y: P.HEIGHT });
    // center circle
    this.strokeCircle({ x: P.WIDTH / 2, y: P.HEIGHT / 2 }, P.CENTER_CIRCLE_RADIUS);
    this.fillCircle({ x: P.WIDTH / 2, y: P.HEIGHT / 2 }, 0.25, "rgba(255,255,255,0.85)");

    // boxes both ends
    for (const side of [0, 1]) {
      const goalX = side === 0 ? 0 : P.WIDTH;
      const dir = side === 0 ? 1 : -1;
      const midY = P.HEIGHT / 2;

      this.strokeRect(
        side === 0 ? 0 : P.WIDTH - P.PENALTY_BOX_DEPTH,
        midY - P.PENALTY_BOX_WIDTH / 2,
        P.PENALTY_BOX_DEPTH, P.PENALTY_BOX_WIDTH
      );
      this.strokeRect(
        side === 0 ? 0 : P.WIDTH - P.GOAL_BOX_DEPTH,
        midY - P.GOAL_BOX_WIDTH / 2,
        P.GOAL_BOX_DEPTH, P.GOAL_BOX_WIDTH
      );
      // penalty spot
      this.fillCircle({ x: goalX + dir * 11, y: midY }, 0.2, "rgba(255,255,255,0.85)");

      // goal frame (net outline behind the goal line)
      const gy0 = midY - P.GOAL_WIDTH / 2, gy1 = midY + P.GOAL_WIDTH / 2;
      this.strokeRect(
        side === 0 ? -P.GOAL_DEPTH : P.WIDTH,
        gy0, P.GOAL_DEPTH, P.GOAL_WIDTH
      );
    }
  }

  drawPlayer(p, isSelected) {
    const ctx = this.ctx;
    const cam = this.camera;
    const s = cam.worldToScreen(p.pos);
    const r = cam.worldScaleToScreen(p.radius());

    // shadow (pseudo-depth for the angled arcade look)
    ctx.beginPath();
    ctx.ellipse(s.x, s.y + r * 0.55, r * 1.05, r * 0.5, 0, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0,0,0,0.28)";
    ctx.fill();

    if (isSelected) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, r * 1.9, 0, Math.PI * 2);
      ctx.strokeStyle = "#ffe14d";
      ctx.lineWidth = 2.5;
      ctx.stroke();
      // little indicator arrow above
      ctx.beginPath();
      ctx.moveTo(s.x, s.y - r * 2.6);
      ctx.lineTo(s.x - r * 0.6, s.y - r * 1.9);
      ctx.lineTo(s.x + r * 0.6, s.y - r * 1.9);
      ctx.closePath();
      ctx.fillStyle = "#ffe14d";
      ctx.fill();
    }

    // body
    ctx.beginPath();
    ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
    ctx.fillStyle = p.isGoalkeeper ? "#e6c400" : p.team.color.primary;
    ctx.fill();
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(0,0,0,0.35)";
    ctx.stroke();

    // facing indicator
    const facePt = Vec.add(s, Vec.fromAngle(p.facing, r * 0.9));
    ctx.beginPath();
    ctx.arc(facePt.x, facePt.y, r * 0.32, 0, Math.PI * 2);
    ctx.fillStyle = p.appearance.skin;
    ctx.fill();

    // shirt number
    ctx.fillStyle = p.team.color.text;
    ctx.font = `bold ${Math.max(8, r * 0.9)}px sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(p.number), s.x, s.y + 1);

    // stunned indicator
    if (p.isStunned()) {
      ctx.fillStyle = "#fff";
      ctx.font = `${r}px sans-serif`;
      ctx.fillText("~", s.x, s.y - r * 1.6);
    }
  }

  drawBall(ball) {
    const ctx = this.ctx;
    const cam = this.camera;
    const s = cam.worldToScreen(ball.pos);
    const heightLift = ball.z * CONFIG.PIXELS_PER_METRE * cam.zoom * cam.squash;
    const r = cam.worldScaleToScreen(ball.radius()) * (1 + ball.z * 0.06);

    // shadow on ground
    ctx.beginPath();
    ctx.ellipse(s.x, s.y + r * 0.4, r * 1.1, r * 0.55, 0, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(s.x, s.y - heightLift, r, 0, Math.PI * 2);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.lineWidth = 1;
    ctx.strokeStyle = "#333";
    ctx.stroke();
  }

  // --- geometry helpers (world-space -> screen) ---
  polygon(points) {
    const ctx = this.ctx;
    ctx.beginPath();
    points.forEach((pt, i) => {
      const s = this.camera.worldToScreen(pt);
      i === 0 ? ctx.moveTo(s.x, s.y) : ctx.lineTo(s.x, s.y);
    });
    ctx.closePath();
    ctx.fill();
  }

  strokeRect(x, y, w, h) {
    this.polylineStroke([
      { x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }, { x, y },
    ]);
  }

  polylineStroke(points) {
    const ctx = this.ctx;
    ctx.beginPath();
    points.forEach((pt, i) => {
      const s = this.camera.worldToScreen(pt);
      i === 0 ? ctx.moveTo(s.x, s.y) : ctx.lineTo(s.x, s.y);
    });
    ctx.stroke();
  }

  strokeLine(a, b) { this.polylineStroke([a, b]); }

  strokeCircle(center, radius) {
    const ctx = this.ctx;
    const s = this.camera.worldToScreen(center);
    const r = this.camera.worldScaleToScreen(radius);
    ctx.beginPath();
    ctx.ellipse(s.x, s.y, r, r * this.camera.squash, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  fillCircle(center, radius, color) {
    const ctx = this.ctx;
    const s = this.camera.worldToScreen(center);
    const r = this.camera.worldScaleToScreen(radius);
    ctx.beginPath();
    ctx.ellipse(s.x, s.y, r, r * this.camera.squash, 0, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
  }
}
