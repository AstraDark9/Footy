// ============================================================================
// camera.js — top-down arcade camera with a slight vertical squash (to fake
// an "angled" look without any real 3D) and smooth follow + zoom on the ball.
// ============================================================================

class Camera {
  constructor(canvas) {
    this.canvas = canvas;
    this.pos = { x: CONFIG.PITCH.WIDTH / 2, y: CONFIG.PITCH.HEIGHT / 2 }; // world-space look target
    this.zoom = 1;
    this.targetZoom = 1;
    this.squash = 0.82; // vertical compression for the pseudo-angled look
  }

  update(dt, focusWorldPos) {
    const t = 1 - Math.pow(0.001, dt); // smooth follow regardless of framerate
    this.pos = Vec.lerp(this.pos, focusWorldPos, t * 3);
    this.zoom += (this.targetZoom - this.zoom) * t * 2;
  }

  // world -> screen pixel transform
  worldToScreen(p) {
    const ppm = CONFIG.PIXELS_PER_METRE * this.zoom;
    const cx = this.canvas.width / 2;
    const cy = this.canvas.height / 2;
    const dx = (p.x - this.pos.x) * ppm;
    const dy = (p.y - this.pos.y) * ppm * this.squash;
    return { x: cx + dx, y: cy + dy };
  }

  worldScaleToScreen(m) {
    return m * CONFIG.PIXELS_PER_METRE * this.zoom;
  }
}
