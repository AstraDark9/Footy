// ============================================================================
// match.js — the match "referee": owns both teams + ball, runs the game
// loop's simulation step (input -> AI -> physics -> collisions -> rules),
// and drives the state machine: KICKOFF -> PLAYING -> HALFTIME -> PLAYING
// -> FULLTIME. Also exposes small query helpers (spaceAroundPoint,
// ballThirdBias, otherTeam) used by the AI/GK systems.
// ============================================================================

const MatchState = {
  MENU: "MENU",
  KICKOFF: "KICKOFF",
  PLAYING: "PLAYING",
  PAUSED: "PAUSED",
  HALFTIME: "HALFTIME",
  FULLTIME: "FULLTIME",
  GOAL: "GOAL", // brief celebration freeze
};

class Match {
  constructor(canvas, input, onStateChange) {
    this.canvas = canvas;
    this.input = input;
    this.onStateChange = onStateChange || (() => {});

    this.camera = new Camera(canvas);
    this.renderer = new Renderer(canvas, this.camera);

    this.halfLengthMinutes = 5;
    this.state = MatchState.MENU;

    this.home = null;
    this.away = null;
    this.ball = null;

    this.half = 1;
    this.halfTimeSeconds = 0; // elapsed seconds in current half
    this.goalFreezeTimer = 0;
    this.lastGoalScorerTeam = null;

    this.selectedPlayer = null;
    this.shootCharge = 0;
    this.isChargingShot = false;
    this.aimDir = { x: 1, y: 0 };

    this.homeAI = null;
    this.awayAI = null;
    this.homeGK = null;
    this.awayGK = null;

    this.events = []; // small on-screen text events e.g. "GOAL!", "Half Time"
  }

  // ---------------------------------------------------------------- setup
  setupNewMatch(halfLengthMinutes) {
    this.halfLengthMinutes = halfLengthMinutes;
    this.home = new Team("HOME", "Home", 1);
    this.away = new Team("AWAY", "Away", -1);
    this.ball = new Ball();

    this.homeAI = new TeamAI(this.home, this);
    this.awayAI = new TeamAI(this.away, this);
    this.homeGK = new GoalkeeperAI(this.home, this);
    this.awayGK = new GoalkeeperAI(this.away, this);

    this.half = 1;
    this.halfTimeSeconds = 0;
    this.home.score = 0;
    this.away.score = 0;

    this.selectedPlayer = this.pickInitialControlledPlayer();
    this.setControlledPlayer(this.selectedPlayer);

    this.lineUpForKickoff(this.home); // home always kicks off half 1
    this.state = MatchState.KICKOFF;
    this.kickoffTimer = 1.0;
    this.pushEvent("Kick Off");
    this.onStateChange(this.state);
  }

  pickInitialControlledPlayer() {
    // a central midfielder is a reasonable, versatile default
    return this.home.players.find(p => p.position === "CM") || this.home.players[6];
  }

  setControlledPlayer(p) {
    if (this.selectedPlayer) this.selectedPlayer.isUserControlled = false;
    this.selectedPlayer = p;
    p.isUserControlled = true;
  }

  otherTeam(team) { return team === this.home ? this.away : this.home; }

  lineUpForKickoff(kickingTeam) {
    this.home.resetToKickoff();
    this.away.resetToKickoff();
    this.ball.owner = null;
    this.ball.pos = { x: CONFIG.PITCH.WIDTH / 2, y: CONFIG.PITCH.HEIGHT / 2 };
    this.ball.vel = { x: 0, y: 0 };
    this.ball.z = 0; this.ball.vz = 0;

    // give the kicking team's nearest central player the ball
    const taker = kickingTeam.players.reduce((best, p) =>
      Vec.dist(p.pos, this.ball.pos) < Vec.dist(best.pos, this.ball.pos) ? p : best
    );
    this.ball.attachTo(taker);
  }

  // -------------------------------------------------------------- control
  pauseToggle() {
    if (this.state === MatchState.PLAYING) {
      this.prevState = MatchState.PLAYING;
      this.state = MatchState.PAUSED;
    } else if (this.state === MatchState.PAUSED) {
      this.state = this.prevState || MatchState.PLAYING;
    }
    this.onStateChange(this.state);
  }

  pushEvent(text) {
    if (!text) return;
    this.events.push({ text, ttl: 2.2 });
  }

  // ----------------------------------------------------------------- loop
  update(dt) {
    dt = Math.min(dt, 0.05); // clamp huge steps (e.g. tab was backgrounded)

    for (const e of this.events) e.ttl -= dt;
    this.events = this.events.filter(e => e.ttl > 0);

    if (this.state === MatchState.KICKOFF) {
      this.kickoffTimer -= dt;
      if (this.kickoffTimer <= 0) {
        this.state = MatchState.PLAYING;
        this.onStateChange(this.state);
      }
      this.stepSimulation(dt, false);
      return;
    }

    if (this.state === MatchState.GOAL) {
      this.goalFreezeTimer -= dt;
      if (this.goalFreezeTimer <= 0) {
        this.restartAfterGoal();
      }
      this.updateCamera(dt);
      return;
    }

    if (this.state !== MatchState.PLAYING) return;

    this.halfTimeSeconds += dt;
    const halfLenSec = this.halfLengthMinutes * 60;
    if (this.halfTimeSeconds >= halfLenSec) {
      this.halfTimeSeconds = halfLenSec;
      this.onHalfEnd();
      return;
    }

    this.stepSimulation(dt, true);
  }

  onHalfEnd() {
    if (this.half === 1) {
      this.state = MatchState.HALFTIME;
      this.pushEvent("Half Time");
      this.onStateChange(this.state);
    } else {
      this.state = MatchState.FULLTIME;
      this.pushEvent("Full Time");
      this.onStateChange(this.state);
    }
  }

  startSecondHalf() {
    this.half = 2;
    this.halfTimeSeconds = 0;
    // the team that didn't start half 1 kicks off half 2
    this.lineUpForKickoff(this.away);
    this.state = MatchState.KICKOFF;
    this.kickoffTimer = 1.0;
    this.pushEvent("Second Half");
    this.onStateChange(this.state);
  }

  restartAfterGoal() {
    const conceding = this.lastGoalScorerTeam === this.home ? this.away : this.home;
    this.lineUpForKickoff(conceding);
    this.state = MatchState.KICKOFF;
    this.kickoffTimer = 1.0;
    this.onStateChange(this.state);
  }

  // ------------------------------------------------------------ simulation
  stepSimulation(dt, allowScoring) {
    this.handleControlledPlayerInput(dt);
    this.homeAI.update(dt);
    this.awayAI.update(dt);
    this.homeGK.update(dt);
    this.awayGK.update(dt);

    for (const p of this.allPlayers()) p.update(dt);
    this.ball.update(dt);

    this.resolvePlayerCollisions();
    this.resolveTackles(dt);
    this.resolveBallControl();

    if (allowScoring) this.checkGoalAndOutOfBounds();

    this.updateCamera(dt);
  }

  allPlayers() { return this.home.players.concat(this.away.players); }

  updateCamera(dt) {
    const focus = this.ball.pos;
    this.camera.targetZoom = 1.15 - clamp(Vec.len(this.ball.vel) / 40, 0, 0.25);
    this.camera.update(dt, focus);
  }

  // ---- input for the human controlled player ----
  handleControlledPlayerInput(dt) {
    const p = this.selectedPlayer;
    const input = this.input;
    const ball = this.ball;

    const moveDir = input.moveVector();
    const sprinting = input.isHeld("sprint");

    if (moveDir) {
      this.aimDir = moveDir;
      const target = Vec.add(p.pos, Vec.scale(moveDir, 8));
      p.steerTo(target, sprinting, dt);
    } else {
      p.steerTo(p.pos, false, dt); // decelerate to a stop
    }

    if (input.wasPressed("switch")) {
      this.switchControlledPlayer();
    }

    const iHaveBall = ball.owner === p;

    if (iHaveBall && input.wasPressed("pass")) {
      const target = this.bestPassTarget(p);
      const dir = target ? Vec.norm(Vec.sub(target.pos, p.pos)) : this.aimDir;
      Actions.pass(ball, p, dir, 0.72, target);
    }

    if (iHaveBall && input.isHeld("shoot")) {
      this.isChargingShot = true;
      this.shootCharge = clamp(this.shootCharge + dt, 0, CONFIG.SHOT.MAX_CHARGE_TIME);
    } else if (this.isChargingShot) {
      const chargeFrac = clamp(this.shootCharge / CONFIG.SHOT.MAX_CHARGE_TIME, 0.25, 1);
      if (iHaveBall) {
        const goal = p.team.opponentGoalCenter();
        const toGoal = Vec.norm(Vec.sub(goal, p.pos));
        const dir = Vec.norm(Vec.add(Vec.scale(this.aimDir, 0.55), Vec.scale(toGoal, 0.75)));
        Actions.shoot(ball, p, dir, chargeFrac, goal);
      }
      this.isChargingShot = false;
      this.shootCharge = 0;
    }

    if (!iHaveBall && input.wasPressed("tackle")) {
      if (Actions.canAttemptTackle(p, ball)) {
        Actions.startTackle(p);
      }
    }
  }

  bestPassTarget(passer) {
    const team = passer.team;
    let best = null, bestScore = -Infinity;
    for (const t of team.players) {
      if (t === passer) continue;
      const toT = Vec.sub(t.pos, passer.pos);
      const dist = Vec.len(toT);
      if (dist < 2 || dist > 45) continue;
      const dirScore = Vec.dot(Vec.norm(toT), this.aimDir);
      if (dirScore < 0.2) continue;
      const openness = this.spaceAroundPoint(t.pos, team);
      const score = dirScore * 2 + openness * 0.3 - dist * 0.01;
      if (score > bestScore) { bestScore = score; best = t; }
    }
    return best;
  }

  switchControlledPlayer() {
    const team = this.selectedPlayer.team;
    const candidates = team.outfield().filter(p => p !== this.selectedPlayer);
    if (candidates.length === 0) return;
    candidates.sort((a, b) => Vec.dist(a.pos, this.ball.pos) - Vec.dist(b.pos, this.ball.pos));
    this.setControlledPlayer(candidates[0]);
  }

  spaceAroundPoint(point, team) {
    const opp = this.otherTeam(team);
    let nearestOppDist = Infinity;
    for (const o of opp.players) {
      const d = Vec.dist(o.pos, point);
      if (d < nearestOppDist) nearestOppDist = d;
    }
    return clamp(nearestOppDist / 15, 0, 1);
  }

  ballThirdBias(team) {
    const nx = clamp(this.ball.pos.x / CONFIG.PITCH.WIDTH, 0, 1);
    const attackingFrac = team.attackDir === 1 ? nx : 1 - nx;
    return clamp((attackingFrac - 0.25) / 0.75, 0, 1);
  }

  // ---------------------------------------------------------- collisions
  resolvePlayerCollisions() {
    const players = this.allPlayers();
    for (let i = 0; i < players.length; i++) {
      for (let j = i + 1; j < players.length; j++) {
        const a = players[i], b = players[j];
        const minDist = a.radius() + b.radius();
        const d = Vec.dist(a.pos, b.pos);
        if (d < minDist && d > 0.001) {
          const push = Vec.scale(Vec.norm(Vec.sub(b.pos, a.pos)), (minDist - d) / 2);
          a.pos = Vec.sub(a.pos, push);
          b.pos = Vec.add(b.pos, push);
        }
      }
    }
  }

  resolveTackles(dt) {
    for (const p of this.allPlayers()) {
      if (!p.tackle.active) continue;
      p.tackle.timer += dt;
      if (p.tackle.phase === "windup" && p.tackle.timer >= CONFIG.TACKLE.WINDUP) {
        p.tackle.phase = "active";
        const result = Actions.resolveTackle(p, this.ball);
        if (result.success) this.pushEvent("Tackle!");
      }
      if (p.tackle.phase === "active" && p.tackle.timer >= CONFIG.TACKLE.WINDUP + 0.05) {
        p.tackle.phase = "recover";
      }
      if (p.tackle.timer >= CONFIG.TACKLE.DURATION) {
        p.tackle.active = false;
        p.tackle.phase = null;
      }
    }
  }

  resolveBallControl() {
    const ball = this.ball;
    if (ball.owner) return;
    if (ball.z > 1.4) return; // ball too high in the air to be controlled

    const players = this.allPlayers()
      .filter(p => !p.isStunned() && p !== ball.kickerImmunity)
      .map(p => ({ p, d: Vec.dist(p.pos, ball.pos) }))
      .sort((a, b) => a.d - b.d);

    if (players.length === 0) return;
    const { p, d } = players[0];
    if (d > CONFIG.PLAYER.CONTROL_RADIUS + p.radius()) return;

    if (p.isGoalkeeper) {
      const speed = Vec.len(ball.vel);
      if (speed > 13 && Math.random() < 0.45) {
        const away = Vec.norm(Vec.add(Vec.sub(p.team.goalCenter(), ball.pos), { x: 0, y: randRange(-1, 1) }));
        ball.kick(Vec.scale(Vec.scale(away, -1), speed * 0.5), 2, p);
        this.pushEvent("Save!");
        return;
      }
    }
    ball.attachTo(p);
  }

  checkGoalAndOutOfBounds() {
    const ball = this.ball;
    const P = CONFIG.PITCH;
    const halfGoal = P.GOAL_WIDTH / 2;
    const inGoalMouthY = Math.abs(ball.pos.y - P.HEIGHT / 2) < halfGoal && ball.z < 2.2;

    if (ball.pos.x <= -0.05 && inGoalMouthY) {
      this.scoreGoal(this.away);
      return;
    }
    if (ball.pos.x >= P.WIDTH + 0.05 && inGoalMouthY) {
      this.scoreGoal(this.home);
      return;
    }

    if (ball.pos.y < -0.2 || ball.pos.y > P.HEIGHT + 0.2) {
      this.handleOutOfBounds("touchline");
      return;
    }
    if ((ball.pos.x < -0.2 || ball.pos.x > P.WIDTH + 0.2) && !inGoalMouthY) {
      this.handleOutOfBounds("goalline");
      return;
    }
  }

  scoreGoal(scoringTeam) {
    scoringTeam.score += 1;
    this.lastGoalScorerTeam = scoringTeam;
    this.state = MatchState.GOAL;
    this.goalFreezeTimer = 2.2;
    this.pushEvent(`GOAL! ${scoringTeam.name}`);
    this.ball.owner = null;
    this.ball.vel = { x: 0, y: 0 };
    this.onStateChange(this.state);
  }

  handleOutOfBounds(kind) {
    const ball = this.ball;
    const P = CONFIG.PITCH;
    const lastTeam = ball.lastTouchedTeam;
    let spot;
    if (kind === "touchline") {
      spot = { x: clamp(ball.pos.x, 1, P.WIDTH - 1), y: ball.pos.y < 0 ? 0.3 : P.HEIGHT - 0.3 };
    } else {
      const wentOutLeft = ball.pos.x < 0;
      const defendingTeam = wentOutLeft
        ? (this.home.attackDir === 1 ? this.home : this.away)
        : (this.home.attackDir === -1 ? this.home : this.away);
      const attackingRestart = lastTeam === defendingTeam; // defender touched last -> corner for attackers
      if (attackingRestart) {
        spot = { x: wentOutLeft ? 0.3 : P.WIDTH - 0.3, y: ball.pos.y < P.HEIGHT / 2 ? 0.3 : P.HEIGHT - 0.3 };
      } else {
        spot = { x: wentOutLeft ? P.GOAL_BOX_DEPTH : P.WIDTH - P.GOAL_BOX_DEPTH, y: P.HEIGHT / 2 };
      }
    }
    ball.owner = null;
    ball.pos = spot;
    ball.vel = { x: 0, y: 0 };
    ball.z = 0; ball.vz = 0;
    ball.kickerImmunity = null;
  }

  // ----------------------------------------------------------------- draw
  render() {
    const r = this.renderer;
    r.clear();
    r.drawPitch();

    const players = this.allPlayers().slice().sort((a, b) => a.pos.y - b.pos.y);
    for (const p of players) {
      r.drawPlayer(p, p === this.selectedPlayer);
    }
    r.drawBall(this.ball);
  }
}
