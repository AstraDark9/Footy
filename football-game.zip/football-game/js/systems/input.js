// ============================================================================
// input.js — keyboard state + edge-triggered action events for the user's
// controlled player. Rebinding-friendly: everything routes through KEYMAP.
// ============================================================================

const KEYMAP = {
  up: ["KeyW", "ArrowUp"],
  down: ["KeyS", "ArrowDown"],
  left: ["KeyA", "ArrowLeft"],
  right: ["KeyD", "ArrowRight"],
  sprint: ["ShiftLeft", "ShiftRight"],
  pass: ["KeyJ", "Space"],
  shoot: ["KeyK"],
  tackle: ["KeyL"],
  switch: ["KeyI", "Tab"],
  pause: ["Escape", "KeyP"],
};

class InputSystem {
  constructor() {
    this.down = new Set();
    this.pressedThisFrame = new Set(); // edge-triggered
    this._pendingPressed = new Set();

    window.addEventListener("keydown", (e) => {
      if (!this.down.has(e.code)) this._pendingPressed.add(e.code);
      this.down.add(e.code);
      // prevent page scroll on space/arrows/tab
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Tab"].includes(e.code)) {
        e.preventDefault();
      }
    });
    window.addEventListener("keyup", (e) => {
      this.down.delete(e.code);
    });
    window.addEventListener("blur", () => {
      this.down.clear();
    });
  }

  // call once per frame after game logic consumed previous edges
  beginFrame() {
    this.pressedThisFrame = this._pendingPressed;
    this._pendingPressed = new Set();
  }

  isHeld(action) {
    return KEYMAP[action].some((code) => this.down.has(code));
  }

  wasPressed(action) {
    return KEYMAP[action].some((code) => this.pressedThisFrame.has(code));
  }

  moveVector() {
    let x = 0, y = 0;
    if (this.isHeld("left")) x -= 1;
    if (this.isHeld("right")) x += 1;
    if (this.isHeld("up")) y -= 1;
    if (this.isHeld("down")) y += 1;
    if (x === 0 && y === 0) return null;
    return Vec.norm({ x, y });
  }
}
