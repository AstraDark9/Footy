// ============================================================================
// CONFIG.js — all tunable constants live here so gameplay can be balanced
// without touching game logic. Also defines the shared "football data"
// shapes (attributes, positions, formation) that the future SIMULATE MATCH
// engine will reuse.
// ============================================================================

const CONFIG = {
  // --- Pitch (in "metres", a virtual unit independent of screen pixels) ---
  PITCH: {
    WIDTH: 105,   // x axis, goal-to-goal
    HEIGHT: 68,   // y axis, touchline-to-touchline
    GOAL_WIDTH: 7.32,
    GOAL_DEPTH: 2,
    PENALTY_BOX_WIDTH: 40.3,
    PENALTY_BOX_DEPTH: 16.5,
    GOAL_BOX_WIDTH: 18.3,
    GOAL_BOX_DEPTH: 5.5,
    CENTER_CIRCLE_RADIUS: 9.15,
  },

  PIXELS_PER_METRE: 9, // world -> screen scale, camera may zoom on top of this

  // --- Player physical constants (before attribute scaling) ---
  PLAYER: {
    RADIUS: 1.0,               // metres
    BASE_MAX_SPEED: 5.8,       // m/s jogging
    SPRINT_MULT: 1.55,
    BASE_ACCEL: 14,            // m/s^2
    TURN_RATE: 12,             // how fast facing direction can rotate (rad/s)
    CONTROL_RADIUS: 1.35,      // how close ball must be to be "controlled"
    STAMINA_MAX: 100,
    STAMINA_SPRINT_DRAIN: 6,   // per second while sprinting
    STAMINA_REGEN: 3,          // per second while not sprinting
    STAMINA_SPEED_PENALTY: 0.4 // max fraction of speed lost at 0 stamina
  },

  BALL: {
    RADIUS: 0.35,
    FRICTION: 1.15,     // ground deceleration factor
    BOUNCE_DAMPING: 0.45,
    GRAVITY: 18,
  },

  PASS: {
    BASE_SPEED: 16,     // m/s at full power
    MIN_SPEED: 7,
    LOFT_THRESHOLD_DIST: 18, // beyond this, hold-pass becomes a lofted through ball
    INACCURACY_BASE: 0.10,   // radians of random spread at 0 passing skill
    INACCURACY_MIN: 0.015,
  },

  SHOT: {
    BASE_SPEED: 24,
    MIN_SPEED: 14,
    MAX_CHARGE_TIME: 0.9,   // seconds held for full power
    INACCURACY_BASE: 0.16,
    INACCURACY_MIN: 0.02,
    LOFT_BASE: 0.28,
  },

  TACKLE: {
    RANGE: 1.9,
    COOLDOWN: 0.8,
    WINDUP: 0.12,
    DURATION: 0.35,
    BASE_SUCCESS: 0.5,
  },

  SWITCH: {
    MAX_RADIUS: 30, // metres, only consider teammates roughly this close
  },

  AI: {
    CHASERS_MAX: 2,          // how many outfield players may press the ball at once
    MARK_RADIUS: 14,
    SUPPORT_SPACING: 8,
    SHAPE_LERP: 0.55,        // how strongly the team shifts shape with ball position
    REACTION_NOISE: 0.15,
  },

  HALF_LENGTHS: [1, 2, 5, 10], // minutes, selectable in UI

  ATTRIBUTES: [
    "pace", "acceleration", "passing", "shooting",
    "dribbling", "tackling", "strength", "stamina",
    "positioning", "reactions"
  ],

  // 11 outfield/keeper slots. Order matters: index 0 is always GK.
  // Coordinates are FORMATION SLOTS in normalized pitch space
  // (0..1 across width, 0..1 across height) for the team attacking
  // toward x=1. The mirrored team (attacking x=0) flips x at runtime.
  FORMATION_433: [
    { pos: "GK",  slot: { x: 0.04, y: 0.50 } },
    { pos: "LB",  slot: { x: 0.18, y: 0.16 } },
    { pos: "CB",  slot: { x: 0.14, y: 0.38 } },
    { pos: "CB",  slot: { x: 0.14, y: 0.62 } },
    { pos: "RB",  slot: { x: 0.18, y: 0.84 } },
    { pos: "CDM", slot: { x: 0.34, y: 0.50 } },
    { pos: "CM",  slot: { x: 0.46, y: 0.30 } },
    { pos: "CAM", slot: { x: 0.50, y: 0.70 } },
    { pos: "LW",  slot: { x: 0.78, y: 0.14 } },
    { pos: "RW",  slot: { x: 0.78, y: 0.86 } },
    { pos: "ST",  slot: { x: 0.86, y: 0.50 } },
  ],

  // Position -> role weighting used by AI to decide defensive/attacking bias
  POSITION_ROLE: {
    GK:  { defend: 1.0, attack: 0.0, holdLine: 1.0 },
    CB:  { defend: 0.95, attack: 0.15, holdLine: 0.9 },
    LB:  { defend: 0.75, attack: 0.45, holdLine: 0.6 },
    RB:  { defend: 0.75, attack: 0.45, holdLine: 0.6 },
    CDM: { defend: 0.7, attack: 0.35, holdLine: 0.55 },
    CM:  { defend: 0.5, attack: 0.55, holdLine: 0.4 },
    CAM: { defend: 0.3, attack: 0.75, holdLine: 0.3 },
    LM:  { defend: 0.45, attack: 0.6, holdLine: 0.4 },
    RM:  { defend: 0.45, attack: 0.6, holdLine: 0.4 },
    LW:  { defend: 0.2, attack: 0.85, holdLine: 0.25 },
    RW:  { defend: 0.2, attack: 0.85, holdLine: 0.25 },
    ST:  { defend: 0.15, attack: 0.95, holdLine: 0.2 },
  },

  TEAM_COLORS: {
    HOME: { primary: "#d6432b", secondary: "#ffffff", text: "#ffffff" },
    AWAY: { primary: "#2b64d6", secondary: "#ffffff", text: "#ffffff" },
  },
};
