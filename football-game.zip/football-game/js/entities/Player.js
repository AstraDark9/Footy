// ============================================================================
// Player.js — a single football player: physical state + attribute-driven
// stats. This same shape is meant to be reused later by a SIMULATE MATCH
// engine, so keep it plain data + pure helper methods (no rendering/canvas
// logic in here).
// ============================================================================

let __playerIdSeq = 1;

class Player {
  /**
   * @param {object} opts
   *  team, number, position (e.g "ST"), attributes {0..99 each}, appearance
   */
  constructor(opts) {
    this.id = __playerIdSeq++;
    this.team = opts.team;               // Team instance, set after construction
    this.number = opts.number;
    this.position = opts.position;       // formation position code
    this.attributes = opts.attributes;   // {pace, acceleration, passing, ...}
    this.appearance = opts.appearance;   // {height, build, skin, hair, hairColor}

    this.pos = { x: 0, y: 0 };           // metres, world space
    this.vel = { x: 0, y: 0 };
    this.facing = 0;                     // radians

    this.formationSlot = opts.formationSlot; // {x,y} normalized 0..1

    this.stamina = CONFIG.PLAYER.STAMINA_MAX;
    this.sprinting = false;

    this.isUserControlled = false;
    this.isGoalkeeper = this.position === "GK";

    // transient action state
    this.tackle = { active: false, timer: 0, phase: null }; // phase: 'windup'|'active'|'recover'
    this.tackleCooldown = 0;
    this.stunTimer = 0; // brief loss of control after being tackled / big collision

    // AI state
    this.aiState = "SUPPORT"; // CHASE | MARK | SUPPORT | RETURN | GK_*
    this.markTarget = null;
  }

  attr(name) { return this.attributes[name] ?? 50; }

  // Effective top speed in m/s, scaled by pace + stamina.
  maxSpeed(sprinting) {
    const paceScale = 0.75 + (this.attr("pace") / 99) * 0.55;
    let s = CONFIG.PLAYER.BASE_MAX_SPEED * paceScale;
    if (sprinting) s *= CONFIG.PLAYER.SPRINT_MULT;
    const staminaFrac = this.stamina / CONFIG.PLAYER.STAMINA_MAX;
    const staminaMult = 1 - (1 - staminaFrac) * CONFIG.PLAYER.STAMINA_SPEED_PENALTY;
    return s * staminaMult;
  }

  accel() {
    const accScale = 0.7 + (this.attr("acceleration") / 99) * 0.7;
    return CONFIG.PLAYER.BASE_ACCEL * accScale;
  }

  radius() {
    // small variation from body build so players don't look identical
    const build = this.appearance.build; // 0.85 .. 1.15
    return CONFIG.PLAYER.RADIUS * build;
  }

  isStunned() { return this.stunTimer > 0; }

  canTackle() { return this.tackleCooldown <= 0 && !this.tackle.active && !this.isStunned(); }

  update(dt) {
    // stamina drain/regen
    if (this.sprinting && Vec.len(this.vel) > 0.5) {
      this.stamina = clamp(this.stamina - CONFIG.PLAYER.STAMINA_SPRINT_DRAIN * dt, 0, CONFIG.PLAYER.STAMINA_MAX);
    } else {
      this.stamina = clamp(this.stamina + CONFIG.PLAYER.STAMINA_REGEN * dt, 0, CONFIG.PLAYER.STAMINA_MAX);
    }

    if (this.tackleCooldown > 0) this.tackleCooldown -= dt;
    if (this.stunTimer > 0) this.stunTimer -= dt;

    // integrate position
    this.pos = Vec.add(this.pos, Vec.scale(this.vel, dt));

    // keep inside pitch bounds (soft clamp, touchline/goal-line runoff)
    const pad = 2;
    this.pos.x = clamp(this.pos.x, -pad, CONFIG.PITCH.WIDTH + pad);
    this.pos.y = clamp(this.pos.y, -pad, CONFIG.PITCH.HEIGHT + pad);
  }

  // Steer velocity toward a desired direction/speed with accel + turn limits.
  steerTo(targetPos, sprinting, dt) {
    if (this.isStunned()) {
      this.vel = Vec.scale(this.vel, Math.max(0, 1 - dt * 6));
      return;
    }
    const toTarget = Vec.sub(targetPos, this.pos);
    const dist = Vec.len(toTarget);
    if (dist < 0.05) {
      this.vel = Vec.scale(this.vel, Math.max(0, 1 - dt * 8));
      return;
    }
    const desiredDir = Vec.scale(toTarget, 1 / dist);
    const topSpeed = this.maxSpeed(sprinting);
    // slow down as we approach target so AI doesn't jitter around slots
    const desiredSpeed = dist < 1.5 ? topSpeed * (dist / 1.5) : topSpeed;
    const desiredVel = Vec.scale(desiredDir, desiredSpeed);

    const diff = Vec.sub(desiredVel, this.vel);
    const maxDv = this.accel() * dt;
    const diffLen = Vec.len(diff);
    if (diffLen <= maxDv) {
      this.vel = desiredVel;
    } else {
      this.vel = Vec.add(this.vel, Vec.scale(diff, maxDv / diffLen));
    }

    if (Vec.len(this.vel) > 0.3) {
      const targetFacing = Vec.angle(this.vel);
      this.facing = moveAngleTowards(this.facing, targetFacing, CONFIG.PLAYER.TURN_RATE * dt);
    }
    this.sprinting = sprinting && Vec.len(this.vel) > 0.5;
  }

  applyImpulse(vec) {
    this.vel = Vec.add(this.vel, vec);
  }

  stun(seconds) {
    this.stunTimer = Math.max(this.stunTimer, seconds);
  }
}
