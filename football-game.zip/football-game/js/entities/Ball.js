// ============================================================================
// Ball.js — ball physics: ground friction + simple projectile arc for
// lofted passes and shots (height is simulated with a scalar z + vz).
// ============================================================================

class Ball {
  constructor() {
    this.pos = { x: CONFIG.PITCH.WIDTH / 2, y: CONFIG.PITCH.HEIGHT / 2 };
    this.vel = { x: 0, y: 0 }; // ground-plane velocity (m/s)
    this.z = 0;                // height above ground (m)
    this.vz = 0;

    this.owner = null;         // Player currently "controlling" the ball, or null
    this.lastTouchedBy = null;
    this.lastTouchedTeam = null;

    // brief window after a kick where it can't be re-collected by the kicker
    // (prevents instantly re-trapping your own pass/shot)
    this.kickerImmunity = null;
    this.kickerImmunityTimer = 0;

    this.inFlight = false; // true while airborne from a lofted kick
  }

  radius() { return CONFIG.BALL.RADIUS; }

  kick(velocityXY, velocityZ, kicker) {
    this.owner = null;
    this.vel = { ...velocityXY };
    this.vz = velocityZ || 0;
    if (this.z <= 0.01) this.z = 0.05;
    this.inFlight = this.vz > 0.5;
    this.lastTouchedBy = kicker;
    this.lastTouchedTeam = kicker ? kicker.team : this.lastTouchedTeam;
    this.kickerImmunity = kicker;
    this.kickerImmunityTimer = 0.25;
  }

  update(dt) {
    if (this.kickerImmunityTimer > 0) {
      this.kickerImmunityTimer -= dt;
      if (this.kickerImmunityTimer <= 0) this.kickerImmunity = null;
    }

    if (this.owner) {
      // ball is glued near the controlling player's feet, slightly ahead of facing
      const ahead = Vec.fromAngle(this.owner.facing, 0.55);
      this.pos = Vec.add(this.owner.pos, ahead);
      this.vel = { x: 0, y: 0 };
      this.z = 0; this.vz = 0;
      return;
    }

    // integrate ground velocity with friction
    const speed = Vec.len(this.vel);
    if (speed > 0.01) {
      const friction = CONFIG.BALL.FRICTION * dt;
      const newSpeed = Math.max(0, speed - friction * (this.z > 0.05 ? 0.15 : 1));
      this.vel = Vec.scale(Vec.norm(this.vel), newSpeed);
    }
    this.pos = Vec.add(this.pos, Vec.scale(this.vel, dt));

    // vertical (height) physics for lofted balls
    if (this.z > 0 || this.vz > 0) {
      this.vz -= CONFIG.BALL.GRAVITY * dt;
      this.z += this.vz * dt;
      if (this.z <= 0) {
        this.z = 0;
        if (Math.abs(this.vz) > 1) {
          this.vz = -this.vz * CONFIG.BALL.BOUNCE_DAMPING;
        } else {
          this.vz = 0;
          this.inFlight = false;
        }
      }
    } else {
      this.inFlight = false;
    }

    // soft pitch runoff bounds (out-of-play handled by Match, not here)
    const pad = 8;
    this.pos.x = clamp(this.pos.x, -pad, CONFIG.PITCH.WIDTH + pad);
    this.pos.y = clamp(this.pos.y, -pad, CONFIG.PITCH.HEIGHT + pad);
  }

  attachTo(player) {
    this.owner = player;
    this.lastTouchedBy = player;
    this.lastTouchedTeam = player.team;
    this.vel = { x: 0, y: 0 };
    this.z = 0; this.vz = 0;
    this.inFlight = false;
  }

  isLoose() { return !this.owner; }
}
