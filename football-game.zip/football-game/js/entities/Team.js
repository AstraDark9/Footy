// ============================================================================
// Team.js — a squad of 11 Players + formation/shape helpers shared by the
// AI system and (eventually) the simulation engine.
// ============================================================================

class Team {
  /**
   * @param {"HOME"|"AWAY"} side
   * @param {1|-1} attackDir 1 = attacking toward x=PITCH.WIDTH, -1 = toward x=0
   */
  constructor(side, name, attackDir) {
    this.side = side;
    this.name = name;
    this.attackDir = attackDir;
    this.color = CONFIG.TEAM_COLORS[side];
    this.score = 0;
    this.players = this.buildSquad();
  }

  buildSquad() {
    return CONFIG.FORMATION_433.map((slotDef, i) => {
      const attributes = generateAttributesForPosition(slotDef.pos);
      const appearance = generateAppearance();
      const p = new Player({
        team: this,
        number: i + 1,
        position: slotDef.pos,
        attributes,
        appearance,
        formationSlot: slotDef.slot,
      });
      return p;
    });
  }

  goalkeeper() { return this.players[0]; }
  outfield() { return this.players.slice(1); }

  // Formation slot in WORLD coordinates for a given normalized ball x
  // (0..1 across the pitch), producing a subtle shape-shift up/downfield.
  slotWorldPos(player, ballNormX) {
    const slot = player.formationSlot;
    // shift the whole shape toward the ball's third, but only a little
    const shapeShift = (ballNormX - 0.5) * CONFIG.AI.SHAPE_LERP;
    let nx = clamp(slot.x + shapeShift * (this.attackDir === 1 ? 1 : -1), 0.03, 0.97);
    let ny = slot.y;

    if (this.attackDir === -1) {
      nx = 1 - nx;
    }
    return {
      x: nx * CONFIG.PITCH.WIDTH,
      y: ny * CONFIG.PITCH.HEIGHT,
    };
  }

  goalCenter(defending = true) {
    // the goal THIS team defends
    const x = this.attackDir === 1 ? 0 : CONFIG.PITCH.WIDTH;
    return { x, y: CONFIG.PITCH.HEIGHT / 2 };
  }

  opponentGoalCenter() {
    const x = this.attackDir === 1 ? CONFIG.PITCH.WIDTH : 0;
    return { x, y: CONFIG.PITCH.HEIGHT / 2 };
  }

  resetToKickoff() {
    for (const p of this.players) {
      const world = this.slotWorldPos(p, 0.5);
      p.pos = { ...world };
      p.vel = { x: 0, y: 0 };
      p.facing = this.attackDir === 1 ? 0 : Math.PI;
      p.stamina = CONFIG.PLAYER.STAMINA_MAX;
      p.tackle = { active: false, timer: 0, phase: null };
      p.tackleCooldown = 0;
      p.stunTimer = 0;
    }
  }
}

// Generate 0..99 attributes biased by position archetype, with some
// individual variance so players on the same team aren't clones.
function generateAttributesForPosition(pos) {
  const base = {
    pace: 60, acceleration: 60, passing: 60, shooting: 45,
    dribbling: 55, tackling: 45, strength: 55, stamina: 65,
    positioning: 55, reactions: 55,
  };
  const archetypes = {
    GK:  { reactions: 85, positioning: 80, strength: 65, pace: 45, shooting: 20, passing: 55, tackling: 30, dribbling: 30 },
    CB:  { tackling: 80, strength: 80, positioning: 75, pace: 55, passing: 55, shooting: 25, dribbling: 40 },
    LB:  { pace: 72, tackling: 65, passing: 60, dribbling: 60, positioning: 60, shooting: 30 },
    RB:  { pace: 72, tackling: 65, passing: 60, dribbling: 60, positioning: 60, shooting: 30 },
    CDM: { tackling: 72, positioning: 72, passing: 68, strength: 68, shooting: 35, pace: 55 },
    CM:  { passing: 74, positioning: 65, dribbling: 65, tackling: 55, shooting: 50, pace: 60 },
    CAM: { passing: 78, dribbling: 75, shooting: 65, positioning: 60, tackling: 35, pace: 62 },
    LM:  { pace: 72, dribbling: 68, passing: 65, shooting: 50, tackling: 45 },
    RM:  { pace: 72, dribbling: 68, passing: 65, shooting: 50, tackling: 45 },
    LW:  { pace: 82, dribbling: 78, shooting: 65, passing: 58, tackling: 25 },
    RW:  { pace: 82, dribbling: 78, shooting: 65, passing: 58, tackling: 25 },
    ST:  { shooting: 80, pace: 74, dribbling: 68, strength: 65, positioning: 72, passing: 50, tackling: 25 },
  };
  const arche = archetypes[pos] || {};
  const out = {};
  for (const key of CONFIG.ATTRIBUTES) {
    const b = arche[key] ?? base[key];
    const variance = randRange(-8, 8);
    out[key] = Math.round(clamp(b + variance, 20, 99));
  }
  return out;
}

function generateAppearance() {
  const skinTones = ["#f2c9a1", "#d9a066", "#a56c3d", "#7a4a24", "#4a2c17"];
  const hairColors = ["#1b1b1b", "#3b2416", "#7a4a1f", "#c9a349", "#5c5c5c"];
  const hairStyles = ["short", "buzz", "long", "bald", "curly"];
  return {
    height: randRange(1.65, 1.95),          // metres, cosmetic only
    build: randRange(0.88, 1.14),           // affects render radius slightly
    skin: choice(skinTones),
    hair: choice(hairStyles),
    hairColor: choice(hairColors),
  };
}
