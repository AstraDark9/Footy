// ============================================================================
// ui.js — all DOM overlay wiring: start menu, HUD, pause/half-time/full-time
// panels, and the help panel. Keeps DOM concerns out of match.js.
// ============================================================================

class UI {
  constructor(match) {
    this.match = match;

    this.el = {
      startMenu: document.getElementById("start-menu"),
      startBtn: document.getElementById("start-btn"),
      halfLenButtons: Array.from(document.querySelectorAll(".half-len-btn")),

      hud: document.getElementById("hud"),
      scoreHome: document.getElementById("score-home"),
      scoreAway: document.getElementById("score-away"),
      timer: document.getElementById("timer"),
      halfLabel: document.getElementById("half-label"),
      selectedName: document.getElementById("selected-name"),
      staminaFill: document.getElementById("stamina-fill"),
      shotChargeWrap: document.getElementById("shot-charge-wrap"),
      shotChargeFill: document.getElementById("shot-charge-fill"),
      eventBanner: document.getElementById("event-banner"),

      pauseBtn: document.getElementById("pause-btn"),
      helpBtn: document.getElementById("help-btn"),

      pausePanel: document.getElementById("pause-panel"),
      resumeBtn: document.getElementById("resume-btn"),
      restartFromPauseBtn: document.getElementById("restart-from-pause-btn"),
      quitBtn: document.getElementById("quit-btn"),

      halftimePanel: document.getElementById("halftime-panel"),
      halftimeScore: document.getElementById("halftime-score"),
      secondHalfBtn: document.getElementById("second-half-btn"),

      fulltimePanel: document.getElementById("fulltime-panel"),
      fulltimeScore: document.getElementById("fulltime-score"),
      newMatchBtn: document.getElementById("new-match-btn"),

      helpPanel: document.getElementById("help-panel"),
      closeHelpBtn: document.getElementById("close-help-btn"),
    };

    this.selectedHalfLength = 5;
    this.bind();
  }

  bind() {
    this.el.halfLenButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        this.el.halfLenButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        this.selectedHalfLength = Number(btn.dataset.minutes);
      });
    });

    this.el.startBtn.addEventListener("click", () => {
      this.hide(this.el.startMenu);
      this.show(this.el.hud);
      this.match.setupNewMatch(this.selectedHalfLength);
    });

    this.el.pauseBtn.addEventListener("click", () => this.match.pauseToggle());
    this.el.resumeBtn.addEventListener("click", () => this.match.pauseToggle());

    this.el.restartFromPauseBtn.addEventListener("click", () => {
      this.hide(this.el.pausePanel);
      this.match.setupNewMatch(this.match.halfLengthMinutes);
    });

    this.el.quitBtn.addEventListener("click", () => {
      this.hide(this.el.pausePanel);
      this.hide(this.el.hud);
      this.show(this.el.startMenu);
      this.match.state = MatchState.MENU;
    });

    this.el.secondHalfBtn.addEventListener("click", () => {
      this.hide(this.el.halftimePanel);
      this.match.startSecondHalf();
    });

    this.el.newMatchBtn.addEventListener("click", () => {
      this.hide(this.el.fulltimePanel);
      this.match.setupNewMatch(this.match.halfLengthMinutes);
    });

    this.el.helpBtn.addEventListener("click", () => this.show(this.el.helpPanel));
    this.el.closeHelpBtn.addEventListener("click", () => this.hide(this.el.helpPanel));

    this.match.onStateChange = (state) => this.onMatchStateChange(state);

    // keyboard shortcuts for pause menu buttons via Escape are handled by
    // InputSystem -> main.js polling match.input.wasPressed("pause")
  }

  onMatchStateChange(state) {
    this.hide(this.el.pausePanel);
    this.hide(this.el.halftimePanel);
    this.hide(this.el.fulltimePanel);

    if (state === MatchState.PAUSED) this.show(this.el.pausePanel);
    if (state === MatchState.HALFTIME) {
      this.el.halftimeScore.textContent =
        `Home ${this.match.home.score} — ${this.match.away.score} Away`;
      this.show(this.el.halftimePanel);
    }
    if (state === MatchState.FULLTIME) {
      this.el.fulltimeScore.textContent =
        `Home ${this.match.home.score} — ${this.match.away.score} Away`;
      this.show(this.el.fulltimePanel);
    }
  }

  show(el) { el.classList.remove("hidden"); }
  hide(el) { el.classList.add("hidden"); }

  formatTime(seconds) {
    const s = Math.max(0, Math.ceil(seconds));
    const m = Math.floor(s / 60);
    const r = s % 60;
    return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
  }

  update() {
    const m = this.match;
    if (!m.home) return;

    this.el.scoreHome.textContent = m.home.score;
    this.el.scoreAway.textContent = m.away.score;

    const remaining = m.halfLengthMinutes * 60 - m.halfTimeSeconds;
    this.el.timer.textContent = this.formatTime(remaining);
    this.el.halfLabel.textContent = m.half === 1 ? "1st Half" : "2nd Half";

    const sp = m.selectedPlayer;
    if (sp) {
      this.el.selectedName.textContent = `#${sp.number} ${sp.position}`;
      this.el.staminaFill.style.width = `${(sp.stamina / CONFIG.PLAYER.STAMINA_MAX) * 100}%`;
    }

    if (m.isChargingShot) {
      this.show(this.el.shotChargeWrap);
      const frac = clamp(m.shootCharge / CONFIG.SHOT.MAX_CHARGE_TIME, 0, 1);
      this.el.shotChargeFill.style.width = `${frac * 100}%`;
    } else {
      this.hide(this.el.shotChargeWrap);
    }

    if (m.events.length > 0) {
      this.el.eventBanner.textContent = m.events[m.events.length - 1].text;
      this.show(this.el.eventBanner);
    } else {
      this.hide(this.el.eventBanner);
    }
  }
}
