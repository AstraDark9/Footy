// ============================================================================
// main.js — bootstraps the canvas, input, match and UI, and runs the fixed
// game loop.
// ============================================================================

(function () {
  const canvas = document.getElementById("game-canvas");

  function resizeCanvas() {
    const wrap = document.getElementById("canvas-wrap");
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = wrap.clientWidth * dpr;
    canvas.height = wrap.clientHeight * dpr;
    canvas.style.width = wrap.clientWidth + "px";
    canvas.style.height = wrap.clientHeight + "px";
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    canvas.__dpr = dpr;
  }

  window.addEventListener("resize", resizeCanvas);
  resizeCanvas();

  const input = new InputSystem();
  const match = new Match(canvas, input, () => {});
  const ui = new UI(match);

  // pause key toggles regardless of current UI panel focus
  function handleGlobalHotkeys() {
    if (input.wasPressed("pause") && (match.state === MatchState.PLAYING || match.state === MatchState.PAUSED)) {
      match.pauseToggle();
    }
  }

  let lastTime = performance.now();

  function loop(now) {
    const dt = Math.min((now - lastTime) / 1000, 0.1);
    lastTime = now;

    // account for devicePixelRatio scaling already applied to the context;
    // renderer draws in CSS pixels, so use the canvas's CSS size here
    const dpr = canvas.__dpr || 1;
    const cssW = canvas.width / dpr;
    const cssH = canvas.height / dpr;
    match.canvas = { width: cssW, height: cssH };
    match.camera.canvas = match.canvas;

    input.beginFrame();
    handleGlobalHotkeys();
    match.update(dt);
    match.render();
    ui.update();

    requestAnimationFrame(loop);
  }

  requestAnimationFrame(loop);
})();
